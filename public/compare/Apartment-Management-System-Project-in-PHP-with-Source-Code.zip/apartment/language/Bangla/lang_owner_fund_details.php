<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ফান্ড তালিকা";
$_data['text_2'] 		= "মালিকের নাম";
$_data['text_3'] 		= "মাস";
$_data['text_4'] 		= "বছর";
$_data['text_5'] 		= "তারিখ";
$_data['text_6'] 		= "পরিমাণ";
$_data['text_7'] 		= "উদ্দেশ্য";
$_data['text_8'] 		= "ফান্ডের বিস্তারিত";
$_data['text_9'] 		= "মোট";
$_data['text_10'] 		= "প্রদানের তারিখ";

?>