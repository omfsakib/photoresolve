<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ইউনিট স্থিতি প্রতিবেদন";
$_data['text_2'] 		= "ফ্লোর নম্বর";
$_data['text_3'] 		= "ইউনিট নম্বর";
$_data['text_4'] 		= "অবস্থা";
$_data['text_5'] 		= "কাজে ব্যস্ত";
$_data['text_6'] 		= "সহজলভ্য";

?>