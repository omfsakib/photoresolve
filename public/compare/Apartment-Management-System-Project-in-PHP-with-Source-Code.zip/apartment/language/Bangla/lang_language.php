<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ভাষা সেটআপ";
$_data['text_2'] 		= "ভাষা নির্বাচন";
$_data['text_3'] 		= "ভাষা নির্বাচন";
$_data['text_4'] 		= "সেটিংস সফলভাবে পরিবর্তন হয়েছে";

?>