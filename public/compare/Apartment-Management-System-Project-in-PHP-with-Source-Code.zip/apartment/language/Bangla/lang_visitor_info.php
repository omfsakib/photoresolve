<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "অথিতি প্রতিবেদন";
$_data['text_2'] 		= "তারিখ";
$_data['text_3'] 		= "নাম";
$_data['text_4'] 		= "ফোন";
$_data['text_5'] 		= "ঠিকানা";
$_data['text_6'] 		= "ফ্লোন নম্বর";
$_data['text_7'] 		= "ইউনিট নম্বর";
$_data['text_8'] 		= "প্রবেশ সময়";
$_data['text_9'] 		= "বাহির সময়";
$_data['text_10'] 		= "মাস";
$_data['text_11'] 		= "বছর";

?>