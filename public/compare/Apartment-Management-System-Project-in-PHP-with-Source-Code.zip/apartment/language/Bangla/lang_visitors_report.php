<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "অতিথি প্রতিবেদন";
$_data['text_2'] 		= "প্রতিবেদন";
$_data['text_3'] 		= "অতিথি প্রতিবেদন ফরম";
$_data['text_4'] 		= "তারিখ নির্বাচন";
$_data['text_5'] 		= "মাস নির্বাচন";
$_data['text_6'] 		= "বছর নির্বাচন";


?>