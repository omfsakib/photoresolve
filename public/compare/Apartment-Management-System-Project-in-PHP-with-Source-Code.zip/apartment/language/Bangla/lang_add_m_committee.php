<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['add_new_m_committee'] 						= "নতুন ব্যবস্থাপনা কমিটি যোগ";
$_data['m_committee'] 								= "ব্যবস্থাপনা কমিটি";
$_data['update_m_committee'] 						= "ব্যবস্থাপনা কমিটি পরিবর্তন";
$_data['add_new_m_committee_information_breadcam'] 	= "ব্যবস্থাপনা কমিটি তথ্য";
$_data['add_new_m_committee_breadcam'] 				= "ব্যবস্থাপনা কমিটি যোগ";
$_data['add_new_m_committee_entry_form'] 			= "ব্যবস্থাপনা কমিটি এন্ট্রি ফর্ম";
$_data['add_new_form_field_text_1'] 				= "মেম্বার নাম";
$_data['add_new_form_field_text_2'] 				= "ইমেইল";
$_data['add_new_form_field_text_3'] 				= "পাসওয়ার্ড";
$_data['add_new_form_field_text_4'] 				= "ফোন";
$_data['add_new_form_field_text_5'] 				= "বর্তমান ঠিকানা";
$_data['add_new_form_field_text_6'] 				= "স্থায়ী ঠিকানা";
$_data['add_new_form_field_text_7'] 				= "জাতীয় পরিচয়পত্র";
$_data['add_new_form_field_text_8'] 				= "পদবী";
$_data['add_new_form_field_text_9'] 				= "যোগদান তারিখ";
$_data['add_new_form_field_text_10'] 				= "শেষ তারিখ";
$_data['add_new_form_field_text_11'] 				= "অবস্থা";
$_data['add_new_form_field_text_12'] 				= "সক্রিয়";
$_data['add_new_form_field_text_13'] 				= "নিষ্ক্রিয়";
$_data['add_new_form_field_text_14'] 				= "ছবি";
$_data['add_new_form_field_text_15'] 				= "নির্বাচন করুন";
$_data['added_m_committee_successfully'] 			= "ব্যবস্থাপনা কমিটি তথ্য সফলভাবে যোগ হয়েছে";
$_data['update_m_committee_successfully'] 			= "ব্যবস্থাপনা কমিটি তথ্য সফলভাবে পরিবর্তন হয়েছে";
$_data['delete_m_committee_information'] 			= "ব্যবস্থাপনা কমিটি তথ্য সফলভাবে মুছে ফেলেছেন।";

?>