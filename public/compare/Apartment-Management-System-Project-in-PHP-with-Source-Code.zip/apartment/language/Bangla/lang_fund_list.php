<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['add_new_fund'] 						= "তহবিল তালিকা";
$_data['fund'] 								= "তহবিল";
$_data['fund_details'] 						= "তহবিল বিস্তারিত";
$_data['update_fund'] 						= "তহবিল পরিবর্তন";
$_data['add_new_fund_breadcam'] 			= "তহবিল যোগ";
$_data['add_new_fund_entry_form'] 			= "তহবিল এ্ট্রি ফর্ম";
$_data['add_new_form_field_text_1'] 		= "মালিক নাম";
$_data['add_new_form_field_text_2'] 		= "মালিক নির্বাচন";
$_data['add_new_form_field_text_3'] 		= "মাস নির্বাচন";
$_data['add_new_form_field_text_4'] 		= "ফোন";
$_data['add_new_form_field_text_5'] 		= "বছর নির্বাচন";
$_data['add_new_form_field_text_6'] 		= "তারিখ";
$_data['add_new_form_field_text_7'] 		= "মোট মুল্য";
$_data['add_new_form_field_text_8'] 		= "খাত";
$_data['added_fund_successfully'] 			= "তহবিল তথ্য সফলভাবে যোগ হয়ছে";
$_data['update_fund_successfully'] 			= "তহবিল তথ্য সফলভাবে যোগ হয়ছে";
$_data['delete_fund_information'] 			= "তহবিল তথ্য সফলভাবে যোগ হয়ছে";

?>