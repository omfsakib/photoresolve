<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "নতুন বিল যোগ";
$_data['text_1_1'] 		= "বিল বিবরণ";
$_data['text_2'] 		= "বিল তথ্য";
$_data['text_3'] 		= "বিল যোগ";
$_data['text_4'] 		= "বিল এন্ট্রি ফর্ম";
$_data['text_5'] 		= "বিলের ধরন";
$_data['text_6'] 		= "ধরন নির্বাচন";
$_data['text_7'] 		= "ইস্যুর তারিখ";
$_data['text_8'] 		= "বিলের মাস";
$_data['text_9'] 		= "মাস নির্বাচন";
$_data['text_10'] 		= "বিলের বছর";
$_data['text_11'] 		= "বছর নির্বাচন";
$_data['text_12'] 		= "মোট মুল্য";
$_data['text_13'] 		= "ডিপজিট ব্যাংক";
$_data['text_14'] 		= "বিবরণ";
$_data['text_15'] 		= "বিল সফলভাবে যোগ হয়েছে";
$_data['text_16'] 		= "বিল সফলভাবে পরিবর্তন হয়েছে";
$_data['text_17'] 		= "বিল সফলভাবে মুছা হয়েছে";

?>