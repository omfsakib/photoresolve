<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['owner_list'] 							 	= "মালিক তালিকা";
$_data['add_new_owner'] 							= "নতুন মালিক যোগ";
$_data['add_new_owner_entry_form'] 					= "মালিক এন্ট্রি ফর্ম";
$_data['add_new_form_field_text_1'] 				= "মালিক নাম";
$_data['add_new_form_field_text_2'] 				= "ইমেইল";
$_data['add_new_form_field_text_3'] 				= "পাসওয়ার্ড";
$_data['add_new_form_field_text_4'] 				= "ফোন";
$_data['add_new_form_field_text_5'] 				= "বর্তমান ঠিকানা";
$_data['add_new_form_field_text_6'] 				= "স্থায়ী ঠিকানা";
$_data['add_new_form_field_text_7'] 				= "জাতীয় পরিচয়পত্র";
$_data['add_new_form_field_text_8'] 				= "মালিক ইউনিট";
$_data['add_new_form_field_text_9'] 				= "ছবি";
$_data['add_new_owner_information_breadcam'] 		= "মালিক তথ্য";
$_data['add_new_owner_breadcam'] 					= "মালিক যোগ";
$_data['added_owner_successfully'] 					= "মালিক তথ্য সফলভাবে যোগ হয়েছে";
$_data['update_owner_successfully'] 				= "মালিক তথ্য সফলভাবে পরিবর্তন হয়েছে";
$_data['owner_details'] 							= "মালিক বিবরণ";

?>