<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "অভিযোগ তালিকা"; 
$_data['text_1_1'] 		= "অভিযোগ বিবরণ";
$_data['text_2'] 		= "অভিযোগ";
$_data['text_3'] 		= "অভিযোগ যোগ";
$_data['text_4'] 		= "অভিযোগ এন্ট্রি ফর্ম";
$_data['text_5'] 		= "শিরনাম";
$_data['text_6'] 		= "বিবরণ";
$_data['text_7'] 		= "তারিখ";
$_data['text_8'] 		= "অভিযোগ সফলভাবে যোগ করা হয়েছে";
$_data['text_9'] 		= "অভিযোগ সফলভাবে পরিবর্তন করা হয়েছে";
$_data['text_10'] 		= "অভিযোগ সফলভাবে মুছে ফেলা হয়েছে";
$_data['text_11'] 		= "মাস";
$_data['text_12'] 		= "বছর";

?>