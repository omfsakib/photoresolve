<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['add_new_floor_top_title'] 					= "Add New Floor";
$_data['add_new_floor_entry_text'] 					= "Floor Entry Form";
$_data['add_new_form_field_text_1'] 				= "Floor No";
$_data['add_new_floor_information_breadcam'] 		= "Floor Information";
$_data['add_new_add_floor_breadcam'] 				= "Add Floor";
$_data['back_text'] 								= "Back";
?>