<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Employee List";
$_data['text_2'] 		= "Name";
$_data['text_3'] 		= "Email";
$_data['text_4'] 		= "Contact";
$_data['text_5'] 		= "Present Address";
$_data['text_6'] 		= "Designation";
$_data['text_7'] 		= "Joining Date";
$_data['text_8'] 		= "Employee Details";
$_data['text_9'] 		= "Permanent Address";

?>