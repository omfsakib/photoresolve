<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Unit Status Report";
$_data['text_2'] 		= "Report";
$_data['text_3'] 		= "Unit Status Report Form";
$_data['text_4'] 		= "Select Status";
$_data['text_5'] 		= "Select";

?>