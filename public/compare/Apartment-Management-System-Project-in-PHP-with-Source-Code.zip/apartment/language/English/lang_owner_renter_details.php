<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Tenant's Details";
$_data['text_2'] 		= "Tenant's Name";
$_data['text_3'] 		= "Email";
$_data['text_4'] 		= "Contact";
$_data['text_5'] 		= "Address";
$_data['text_6'] 		= "Floor No";
$_data['text_7'] 		= "Unit No";
$_data['text_8'] 		= "Advance Rent";
$_data['text_9'] 		= "Rent Date";
$_data['text_10'] 		= "Rent Per Month";

?>